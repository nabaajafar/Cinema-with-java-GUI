/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinema;

/**
 *
 * @author LENOVO
 * 
 */

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.ListSelectionModel;

public class Snack extends JFrame {
    
     JLabel drinkLbl=new JLabel("drinks:");
     JLabel popcornLbl=new JLabel("kind of popcorn:");
     JLabel otherSnackLbl=new JLabel("Other Snacks:");
     
     String[]drinkArry={"pepsi","seven up","mirinda","water"}; 
     JList drinkList=new JList(drinkArry);
     String[]otherSnackArry={"chocolate","cookies","cake","nuts","grape leaves","cheaps"};
     JList otherSnackList=new JList(otherSnackArry);
     
     JRadioButton poptybeRadio1=new JRadioButton("Caramel");
     JRadioButton poptybeRadio2=new JRadioButton("Salt");
     JRadioButton poptybeRadio3=new JRadioButton("Butter");
     ButtonGroup Group = new ButtonGroup();
    
     JButton nxtButton=new JButton("Next");
     
     JPanel drinkp =new JPanel(); 
     JPanel Lblpopcornp =new JPanel(); 
     JPanel popcornp =new JPanel(); 
     JPanel otherSnakp =new JPanel(); 
     JPanel nxtp =new JPanel();
     JPanel arrangp =new JPanel();
   
    public Snack(){
        super("SNACK");
        setLayout(new FlowLayout());
        
        drinkp.setLayout( new BoxLayout(drinkp, BoxLayout.X_AXIS));
        popcornp.setLayout(new BoxLayout (popcornp,BoxLayout.X_AXIS));
        otherSnakp.setLayout( new BoxLayout(otherSnakp, BoxLayout.X_AXIS));
        arrangp.setLayout(new BoxLayout(arrangp, BoxLayout.Y_AXIS));
        
        arrangp.add(drinkp);
        arrangp.add(Lblpopcornp); 
        arrangp.add(popcornp);
        arrangp.add(otherSnakp);
        arrangp.add(nxtp);
       
        drinkList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        otherSnackList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
       
        add(arrangp);
        
        
        drinkp.add(drinkLbl);
        drinkp.add(drinkList);
        
        Lblpopcornp.add(popcornLbl);
        Group.add(poptybeRadio1);
        Group.add(poptybeRadio2);
        Group.add(poptybeRadio3);
        
        popcornp.add(poptybeRadio1);
        popcornp.add(poptybeRadio2);
        popcornp.add(poptybeRadio3);
        otherSnakp.add(otherSnackLbl);
        otherSnakp.add(otherSnackList);
        
        nxtButton.addActionListener(
                new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                
            }
                    
                }
        );
        nxtp.add(nxtButton);
        
    }
    
}
